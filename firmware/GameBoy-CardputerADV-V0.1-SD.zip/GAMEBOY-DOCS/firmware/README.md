# Firmware V0.1

- `GameBoy-CardputerADV-V0.1-app.bin`: aplicación para M5Launcher.
- `GameBoy-CardputerADV-V0.1-SD.zip`: aplicación, documentación y carpetas vacías.
- `SHA256SUMS`: integridad del BIN.

No contienen ROMs de arranque, cartuchos ni partidas. Copia tu `DMG.ROM` de
256 bytes a `/GAMEBOY/DMG.ROM` y tus `.gb` a `/GAMEBOY/GAMES/GB/`.

Compilación: `sh scripts/build.sh`. Paquete: `python3 scripts/package-sd.py`.
El BIN es de aplicación, no de flash completa. La instalación y la prueba en
el dispositivo físico están pendientes; véase [VALIDACION.md](../VALIDACION.md).
