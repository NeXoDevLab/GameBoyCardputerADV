# Validación V0.1 — 22 de noviembre de 2026

## Comprobado en ordenador

`sh tests/run_host.sh` compila C99/C++17 con AddressSanitizer y
UndefinedBehaviorSanitizer. Usa únicamente ROMs/cartuchos sintéticos originales.

- Cabeceras, checksum, rechazo de tamaños inválidos antes de entrar al núcleo,
  cartuchos truncados, controladores no admitidos y Game Boy Color exclusivo.
- Caché de ROM: lecturas sin acceso SD adicional para cartuchos de 32 KiB y
  expulsión/recarga de páginas para ROMs de mayor tamaño.
- Arranque en PC=0 con boot de prueba, ejecución de sus instrucciones,
  desmapeo FF50 y continuación en el cartucho desde 0x100.
- Reinicio original/directo y conservación de la RAM de cartucho al reiniciar.
- Gráficos de tiles, generación de audio del APU, lectura de botones y
  escrituras en RAM con detección de cambios.
- Errores de opcode y de lectura SD: detienen la CPU sin volver a rutas
  marcadas como inalcanzables por el núcleo.
- HALT permanente con LCD encendida/apagada e interrupciones desactivadas:
  conserva PC y devuelve fotogramas para que la interfaz siga respondiendo.
- Filtro de pantalla: 150×135 proporcional, 240×135 ancho, verdes/grises y
  conservación de trazos finos en la reducción.
- Cola de audio: orden, llena/vacía, reutilización y 10.000 paquetes con
  productor y consumidor concurrentes.
- Preparación de carpetas SD, `.gb` en raíz/subcarpetas, preservación de
  archivos, exclusión de `._`, `.sav` y `.gbc`, límite y navegación por páginas.

`python3 tests/record_protocol.py`: cuatro pruebas superadas para imágenes de
dos bits, cadencia vídeo/audio, paquetes corruptos/truncados y transporte serial
binario mediante un pseudoterminal POSIX. No requieren el Cardputer.

La imagen `tests/.build/synthetic-gameboy.ppm` es un patrón de prueba. No es una
captura de un juego comercial ni del Cardputer físico.

## Compilación y paquete

Perfil de destino: `m5stack:esp32:m5stack_cardputer`, M5Stack ESP32 3.3.10,
240 MHz, flash QIO de 8 MB, `default_8MB`, PSRAM desactivada y USB CDC activo.
Bibliotecas oficiales locales: M5Cardputer 1.1.1, M5Unified 0.2.28 y M5GFX 0.2.35.

Los scripts fijan versiones y comprueban SHA256 de los ZIP de bibliotecas.
No utilizan las copias globales, que en este ordenador contienen duplicados de
algunos archivos de M5GFX. Los núcleos tienen commit de procedencia registrado
en `src/vendor/`.

El resultado final de compilación y el SHA256 del BIN se registran en
`firmware/BUILD-INFO.txt` y `firmware/SHA256SUMS` al preparar la entrega.

**Compilación final superada:** 670.991 bytes de programa (20% del máximo) y
92.852 bytes de datos globales (28% de SRAM). El BIN de aplicación ocupa
671.136 bytes. Los datos globales no incluyen todas las reservas dinámicas
del núcleo, RAM de cartucho y bibliotecas; falta medir el heap en hardware.
Se comprobó que las copias C/C++ procesadas por Arduino corresponden a los
archivos actuales del proyecto.

También se verificó fuera de hardware una exportación FFmpeg del protocolo
sintético a H.264 240×136 con audio AAC. El WAV fuente usa 16.365 Hz; FFmpeg
remuestrea a 16.000 Hz para AAC. No equivale a validar la captura USB real.

## Pendiente de comprobar en hardware

No hay Cardputer detectado en los puertos USB inspeccionados durante esta
sesión. No se ha flasheado el dispositivo ni modificado su tarjeta SD.
Tampoco hay una ROM de arranque DMG ni cartuchos `.gb` aportados en este proyecto.

- Instalación con M5Launcher, arranque con/sin SD y avisos de ROM ausente.
- Encendido con un volcado DMG auténtico, logo, sonido y entrada al juego.
- Teclas, combinaciones de botones, G0, volumen, selector y reanudación.
- Compatibilidad comercial y temporización de CPU, vídeo y APU.
- Continuidad del altavoz y efecto de las faltas de caché SD en cartuchos grandes.
- Guardar/cerrar/reabrir partidas, fallos de escritura y recuperación `.bak`.
- Captura/grabación USB en hardware, sincronía y desconexión durante transmisión.
- Memoria libre con cartuchos de mucha RAM y sesiones prolongadas.

No se afirman 60 fps en hardware, compatibilidad general con juegos ni un
encendido auténtico ya comprobado. RTC MBC3 no se guarda entre sesiones;
el audio se sintetiza por fotograma y el vídeo tiene las limitaciones del núcleo.
