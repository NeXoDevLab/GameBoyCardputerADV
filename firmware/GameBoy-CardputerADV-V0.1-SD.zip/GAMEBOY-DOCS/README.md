# Game Boy DMG para Cardputer ADV

Emulador independiente de la **Game Boy clásica** para **M5Stack Cardputer ADV**,
en la misma línea de los proyectos Amstrad CPC 464 y Spectrum 48K: archivos en
microSD, teclado integrado, audio emulado, selector por carpetas y firmware de
aplicación para M5Launcher. Sin PSRAM.

**V0.1 · desarrollo · pruebas sintéticas en ordenador superadas.**
La instalación y el rendimiento en un Cardputer físico y la secuencia con una
ROM de arranque auténtica siguen pendientes. No se han probado juegos comerciales.

[Guía](docs/GUIA.md) · [Validación y límites](VALIDACION.md) ·
[Firmware](firmware/README.md) · [Créditos](THIRD_PARTY_NOTICES.md)

## Arranque original

El modo **O: original**, seleccionado por defecto, ejecuta tu ROM de arranque DMG
de **256 bytes** desde la dirección cero. Esa ROM es la que debe generar el
desplazamiento del logo, el sonido de encendido y la entrada al cartucho. No se
añade una animación ni un sonido pregrabado. Si falta la ROM o su tamaño es
incorrecto, el programa muestra un aviso y no sustituye el arranque original.

Game Boy utiliza cartuchos: la experiencia original es el encendido y el arranque
del juego, sin una espera de cinta. El modo **R: directo** permite omitir la ROM de
arranque cuando se elige expresamente. La exactitud queda limitada por Peanut-GB
y MiniGB APU; no se afirma emulación ciclo a ciclo.

## Misma estructura de microSD

```text
/GAMEBOY/DMG.ROM                 tu ROM de arranque DMG: 256 bytes
/GAMEBOY/GAMES/GB/               tus cartuchos .gb
/GAMEBOY/GAMES/GB/Aventura/      subcarpetas opcionales
/GAMEBOY/GAMES/GB/Juego.gb
/GAMEBOY/GAMES/GB/Juego.sav      RAM de partida, creada al guardar
```

También se pueden abrir `.gb` sueltos en `GAMES/`. El selector oculta archivos
auxiliares `._` de macOS y archivos de partidas. Las carpetas se crean si faltan;
no se trasladan tus archivos ni se modifican las carpetas CPC464 o SPECTRUM.
**No se incluyen ROMs de arranque ni juegos**, tampoco dentro del firmware o ZIP.

## Funciones

- Game Boy DMG con núcleo Peanut-GB y audio de cuatro canales MiniGB APU.
- Cartuchos ROM, MBC1, MBC2, MBC3 y MBC5 sin periféricos especiales.
- Caché de SD de 32 KiB: los cartuchos grandes no se cargan enteros en RAM y no
  se borran particiones de flash para almacenarlos.
- Paleta verde y alternativa gris; imagen completa filtrada a 150×135, centrada
  y conservando proporción. Ancho completo 240×135 opcional.
- CPU/APU calculan cada fotograma. LCD y reproducción de audio usan tareas
  separadas; la presentación LCD está limitada a unos 30 fps.
- RAM de cartuchos con batería en `.sav`, guardado al abrir el selector,
  cambiar/reiniciar el juego, pulsar Fn+S y cada 30 segundos si hay cambios.
- Copia anterior `.sav.bak` y archivo temporal `.sav.tmp` al guardar.
- Captura LCD y grabación USB de imagen y audio para preparar vídeos.

## Controles

| Tecla | Acción |
| --- | --- |
| Tab / G0 | Abrir o cerrar selector; guarda y pausa el juego |
| Flechas impresas sin Fn / WASD | Cruceta |
| Z / espacio | A |
| X | B |
| Enter | Start; en el selector, entrar/cargar |
| Retroceso | Select; en el selector, subir una carpeta |
| Izquierda/derecha en selector | Cambiar una página de seis filas |
| O / R en selector | Encendido original / entrada directa |
| Fn+= / Fn+- | Volumen en pasos de unos 5 puntos; inicial 30% |
| Fn+R | Reiniciar el cartucho con el modo seleccionado |
| Fn+S | Guardar RAM de partida |
| Fn+W | Proporción original / ancho completo |
| Fn+P | Verde / gris |

Antes de apagar, abre el selector con Tab y comprueba que no aparece un error de
guardado. Un corte de alimentación antes del guardado puede perder cambios
recientes. Los `.sav` guardan la RAM del cartucho, no una instantánea del emulador.

## Compilar y probar

Dependencias del entorno: Arduino CLI, M5Stack ESP32 **3.3.10**,
M5Cardputer **1.1.1**, M5Unified **0.2.28** y M5GFX **0.2.35**.
El script descarga versiones oficiales a `.build-deps/` la primera vez, sin
modificar las bibliotecas globales del ordenador. Requiere red en esa descarga;
las compilaciones siguientes reutilizan las copias locales.

```sh
sh tests/run_host.sh
sh scripts/build.sh
python3 scripts/package-sd.py
```

Perfil: ESP32-S3 a 240 MHz, flash QIO de 8 MB, `default_8MB`, PSRAM desactivada,
USB Hardware CDC/JTAG y CDC al arrancar. El BIN es de **aplicación**, para
M5Launcher; no es una imagen completa para escribir en la dirección cero.

## Límites de esta primera versión

- Solo Game Boy DMG y cartuchos compatibles con DMG. Game Boy Color exclusivo,
  Advance, ZIP, cámaras, vibración y cable link no están implementados.
- Validación estricta de cabecera, tamaños y checksum antes de entrar al núcleo.
- El tamaño máximo de ROM validable es 8 MiB; la RAM de cartucho depende de la
  memoria libre. No equivale a compatibilidad comprobada con esos cartuchos.
- RTC MBC3 avanza dentro del núcleo durante la sesión, pero no se conserva en
  disco ni avanza con el dispositivo apagado. No elegir esta versión para una
  partida que necesite un reloj persistente.
- Las faltas de caché de cartuchos grandes requieren lecturas SD y pueden
  provocar pausas. Falta medir el rendimiento y ajustar audio/SD en hardware.
- El audio se sintetiza por fotograma; tiene limitaciones de temporización.
  Una grabación USB puede tardar más que su duración emulada.

Los resultados reproducibles y la lista de comprobaciones físicas están en
[VALIDACION.md](VALIDACION.md).
