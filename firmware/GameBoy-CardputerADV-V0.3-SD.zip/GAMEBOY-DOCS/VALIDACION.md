# Validación V0.3 — 22 de noviembre de 2026

## Resultado en Cardputer ADV real

Se instaló Game Boy en la partición que ocupaba Amstrad, a `0x6f0000`, con
sustitución expresamente autorizada por el usuario. Launcher, Bruce, RFID y las
otras particiones conservan sus direcciones y tamaños. La escritura de la
aplicación y los metadatos de arranque terminó con verificación de hash.

Antes de instalar se guardó una copia completa de la flash de 8 MB y se extrajo
Amstrad FIX12. Su SHA256 coincide con el firmware original del proyecto. Las
copias quedan en `.device-backups/`, excluidas de los paquetes y del repositorio.

La microSD contenía `DMG.rom.bin`; se creó una copia verificada como
`/GAMEBOY/DMG.ROM`, conservando el archivo original. Se comprobó:

- Tamaño: **256 bytes**.
- MD5: **32fbbd84168d3482956eb3c5051637f5**, correspondiente al boot DMG clásico.
- Ejecución desde PC=0, desplazamiento del logo Nintendo, sonido generado por
  el APU y continuación en el cartucho.
- Tetris `(W) (V1.1) [!]`: arranque original, copyright y menú GAME TYPE / MUSIC TYPE.
- Captura LCD y protocolo de grabación USB de vídeo y audio en el dispositivo.

La prueba de audio nativo registra aproximadamente **59,723 frames/s**, cola
estable de cuatro paquetes y **cero vaciados, paquetes perdidos, errores I2S y
expiraciones de espera**. La observación inicial duró 45 segundos; otra lectura
con más de 11.900 fotogramas mantuvo esos contadores a cero, tras más de tres
minutos de ejecución. Los registros completos están en `docs/hardware-20261122/`.
El binario final, con borrado automático de DMA, repitió una prueba de 60
segundos sin errores y mantuvo aproximadamente 59,7 frames/s.
La confirmación auditiva de la V0.3 en el altavoz está pendiente de respuesta
del usuario; la V0.2 fue descartada por distorsión que aparecía al rato.

## Cambios de sonido

V0.3 utiliza el controlador I2S de ESP-IDF directamente con el códec ES8311 del
ADV. Evita el mezclador/remuestreador de M5Speaker para el flujo continuo.
Inicializa el códec por I2C sin arrancar y destruir el motor asíncrono de M5;
una primera prueba de esa transición reiniciaba el dispositivo y fue corregida.

- PCM mono de 32.731 muestras/s, duplicado en los dos slots I2S de 16 bits.
- El reloj I2S regula la CPU; la emulación rellena la reserva tras una pausa.
- Ceros explícitos al pausar o faltar muestras, y borrado automático de DMA.
- Mezcla ancha y 6 dB de margen antes de reducir a PCM de 16 bits.
- Volumen NR32 del canal de onda aplicado una sola vez y con nivel normalizado.
- Filtro de continua continuo entre paquetes para reducir saltos y chasquidos.
- Intérprete en RAM interna, caché rápida, escalado equivalente píxel a píxel
  y envío LCD limitado al área de imagen cuando los márgenes ya están negros.

## Pruebas automáticas

`sh tests/run_host.sh` usa C99/C++17 con AddressSanitizer y
UndefinedBehaviorSanitizer. No necesita ROMs comerciales.

- Cabeceras, checksum, tamaños malformados, cartuchos truncados y rechazo CGB exclusivo.
- Caché paginada, lecturas fuera de rango y retirada de SD.
- Boot sintético, desmapeo FF50, reset original/directo y RAM de cartucho.
- CPU, tiles, audio, controles, opcode inválido y HALT permanente con/sin LCD.
- Interrupción VBLANK, vector, bandera HRAM, RETI y continuación del programa.
- Escalado: cada fila y ambas anchuras/paletas comparadas con el filtro de referencia.
- Cola de audio: llena/vacía, orden y 10.000 paquetes concurrentes.
- Canal de onda: normalización, niveles NR32 mitad/cuarto y margen de mezcla.
- Carpetas SD, exclusión de archivos auxiliares y partidas, orden y paginación.

`python3 tests/record_protocol.py`: cinco pruebas del empaquetado de imagen,
cadencia, muestras actuales/antiguas, datos corruptos y transporte en pseudoterminal.
La captura antigua V0.1 conserva su frecuencia original de 16.365 Hz; el grabador
admite también V0.2/V0.3 a 32.731 Hz. Los MP4 usan AAC con remuestreo de FFmpeg.

## Compilación y alcance

M5Stack ESP32 3.3.10; M5Cardputer 1.1.1, M5Unified 0.2.28 y M5GFX 0.2.35 en
copias locales verificadas. Perfil QIO de 8 MB, 240 MHz, PSRAM desactivada y USB
CDC. BIN, huella de fuentes y fecha: `firmware/BUILD-INFO.txt`, `SHA256SUMS` y
`SOURCE-SHA256SUMS`. La compilación verifica las copias C/C++ procesadas por Arduino.

La imagen `tests/.build/synthetic-gameboy.ppm` es sintética. Las capturas bajo
`docs/hardware-20261122/` proceden del Cardputer real; el vídeo USB es captura de
la emulación, no una filmación de la carcasa o del altavoz físico.

Faltan pruebas amplias de compatibilidad, partidas/cortes de alimentación,
cartuchos grandes con muchas faltas de caché, RTC persistente y sesiones de
varias horas. No se han probado todos los juegos presentes en la SD. La APU
continúa trabajando por fotogramas y no se afirma exactitud ciclo a ciclo.
